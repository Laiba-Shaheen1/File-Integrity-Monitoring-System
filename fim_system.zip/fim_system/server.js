/**
 * FIM System — server.js
 * Launcher script for the File Integrity Monitoring System.
 *
 * What it does:
 *   1. Checks Python 3 is installed
 *   2. Installs Python dependencies (customtkinter, watchdog, Pillow)
 *   3. Verifies the project folder structure is correct
 *   4. Spawns main.py as a child process
 *   5. Streams stdout/stderr output to the terminal with colour
 *   6. Handles clean shutdown (Ctrl+C kills Python too)
 *
 * Usage:
 *   node server.js               — normal launch
 *   node server.js --skip-deps  — skip pip install (faster after first run)
 *   node server.js --setup-only — install deps then exit, don't launch app
 */

const { spawn, execSync } = require("child_process");
const path  = require("path");
const fs    = require("fs");

// ── Colours ───────────────────────────────────────────────────────────────────
const C = {
  reset:  "\x1b[0m",
  bold:   "\x1b[1m",
  dim:    "\x1b[2m",
  cyan:   "\x1b[36m",
  green:  "\x1b[32m",
  yellow: "\x1b[33m",
  red:    "\x1b[31m",
  blue:   "\x1b[34m",
  white:  "\x1b[37m",
};

const log  = (msg)        => console.log(`${C.cyan}[FIM]${C.reset} ${msg}`);
const ok   = (msg)        => console.log(`${C.green}[OK]${C.reset}  ${msg}`);
const warn = (msg)        => console.log(`${C.yellow}[WARN]${C.reset} ${msg}`);
const err  = (msg)        => console.log(`${C.red}[ERR]${C.reset}  ${msg}`);
const dim  = (msg)        => console.log(`${C.dim}${msg}${C.reset}`);

// ── Config ────────────────────────────────────────────────────────────────────
const PROJECT_ROOT = path.resolve(__dirname);   // folder where server.js lives
const MAIN_PY      = path.join(PROJECT_ROOT, "main.py");

const REQUIRED_PACKAGES = ["customtkinter", "watchdog", "Pillow"];

const REQUIRED_STRUCTURE = [
  "main.py",
  "core/__init__.py",
  "core/database.py",
  "core/hash_engine.py",
  "core/file_watcher.py",
  "core/report_generator.py",
  "gui/__init__.py",
  "gui/app.py",
  "gui/theme.py",
  "gui/widgets.py",
  "gui/pages/__init__.py",
  "gui/pages/dashboard.py",
  "gui/pages/monitoring.py",
  "gui/pages/alerts.py",
  "gui/pages/logs.py",
  "gui/pages/reports.py",
  "gui/pages/settings.py",
];

// Parse CLI flags
const SKIP_DEPS  = process.argv.includes("--skip-deps");
const SETUP_ONLY = process.argv.includes("--setup-only");

// ── Step 1: Banner ────────────────────────────────────────────────────────────
function printBanner() {
  console.log();
  console.log(`${C.cyan}${C.bold}  ╔══════════════════════════════════════════╗`);
  console.log(`  ║   🛡️  File Integrity Monitoring System   ║`);
  console.log(`  ║              Launcher v1.0               ║`);
  console.log(`  ╚══════════════════════════════════════════╝${C.reset}`);
  console.log();
}

// ── Step 2: Find Python ───────────────────────────────────────────────────────
function findPython() {
  const candidates = ["python3", "python", "python3.11", "python3.10", "python3.9"];

  for (const cmd of candidates) {
    try {
      const version = execSync(`${cmd} --version 2>&1`, { encoding: "utf8" }).trim();
      const match   = version.match(/Python (\d+)\.(\d+)/);
      if (match) {
        const major = parseInt(match[1]);
        const minor = parseInt(match[2]);
        if (major === 3 && minor >= 8) {
          ok(`Found ${version}  (${cmd})`);
          return cmd;
        } else {
          warn(`${version} found but Python 3.8+ required`);
        }
      }
    } catch (_) {
      // candidate not found, try next
    }
  }

  err("Python 3.8+ not found. Please install Python from https://www.python.org");
  process.exit(1);
}

// ── Step 3: Check project structure ──────────────────────────────────────────
function checkStructure() {
  log("Checking project structure…");
  const missing = [];

  for (const rel of REQUIRED_STRUCTURE) {
    const full = path.join(PROJECT_ROOT, rel);
    if (!fs.existsSync(full)) {
      missing.push(rel);
    }
  }

  if (missing.length === 0) {
    ok("All required files present.");
  } else {
    warn(`Missing ${missing.length} file(s):`);
    missing.forEach(f => console.log(`  ${C.yellow}✗${C.reset}  ${f}`));

    // Fatal only if main.py or core files are missing
    const fatal = missing.filter(f =>
      f === "main.py" || f.startsWith("core/") || f === "gui/app.py"
    );
    if (fatal.length > 0) {
      err("Critical files missing. Cannot launch.");
      err("Make sure server.js is in the FIM_SYSTEM project root folder.");
      process.exit(1);
    } else {
      warn("Some GUI page files missing — app may still start.");
    }
  }
}

// ── Step 4: Create required directories ──────────────────────────────────────
function createDirs() {
  const dirs = ["reports", "assets"];
  for (const d of dirs) {
    const full = path.join(PROJECT_ROOT, d);
    if (!fs.existsSync(full)) {
      fs.mkdirSync(full, { recursive: true });
      log(`Created directory: ${d}/`);
    }
  }
}

// ── Step 5: Install Python deps ───────────────────────────────────────────────
function installDeps(python) {
  if (SKIP_DEPS) {
    warn("--skip-deps flag set — skipping pip install.");
    return;
  }

  log("Installing Python dependencies…");
  const packages = REQUIRED_PACKAGES.join(" ");

  try {
    // Check which are already installed
    const already = [];
    const toInstall = [];

    for (const pkg of REQUIRED_PACKAGES) {
      try {
        execSync(`${python} -c "import ${pkg.toLowerCase().replace("-", "_")}"`,
                 { stdio: "pipe" });
        already.push(pkg);
      } catch (_) {
        toInstall.push(pkg);
      }
    }

    if (already.length > 0) {
      already.forEach(p => ok(`Already installed: ${p}`));
    }

    if (toInstall.length === 0) {
      ok("All dependencies already satisfied.");
      return;
    }

    log(`Installing: ${toInstall.join(", ")}…`);
    execSync(
      `${python} -m pip install ${toInstall.join(" ")} --quiet`,
      { stdio: "inherit", cwd: PROJECT_ROOT }
    );
    ok("Dependencies installed.");

  } catch (e) {
    err("pip install failed. Try running manually:");
    err(`  ${python} -m pip install ${packages}`);
    err("Then re-run: node server.js --skip-deps");
    process.exit(1);
  }
}

// ── Step 6: Launch main.py ────────────────────────────────────────────────────
function launchApp(python) {
  console.log();
  log(`${C.bold}Launching FIM application…${C.reset}`);
  log(`Command: ${python} ${MAIN_PY}`);
  log(`CWD:     ${PROJECT_ROOT}`);
  console.log();
  dim("─".repeat(60));

  const child = spawn(python, [MAIN_PY], {
    cwd:   PROJECT_ROOT,
    stdio: ["inherit", "pipe", "pipe"],
    env:   { ...process.env, PYTHONUNBUFFERED: "1" },
  });

  // Stream stdout
  child.stdout.on("data", (data) => {
    const lines = data.toString().split("\n");
    lines.forEach(line => {
      if (line.trim()) {
        // Colour-code Python output based on content
        if (/error|exception|traceback/i.test(line)) {
          process.stdout.write(`${C.red}${line}${C.reset}\n`);
        } else if (/warning/i.test(line)) {
          process.stdout.write(`${C.yellow}${line}${C.reset}\n`);
        } else if (/ok|success|done|created|start/i.test(line)) {
          process.stdout.write(`${C.green}${line}${C.reset}\n`);
        } else {
          process.stdout.write(`${C.dim}${line}${C.reset}\n`);
        }
      }
    });
  });

  // Stream stderr
  child.stderr.on("data", (data) => {
    const lines = data.toString().split("\n");
    lines.forEach(line => {
      if (line.trim()) {
        // Tkinter/CTk warnings are harmless — show dimmed
        if (/UserWarning|DeprecationWarning|warning/i.test(line)) {
          process.stdout.write(`${C.yellow}${C.dim}${line}${C.reset}\n`);
        } else if (/error|exception|traceback/i.test(line)) {
          process.stdout.write(`${C.red}${line}${C.reset}\n`);
        } else {
          process.stdout.write(`${C.dim}${line}${C.reset}\n`);
        }
      }
    });
  });

  // App exited
  child.on("close", (code) => {
    dim("─".repeat(60));
    console.log();
    if (code === 0 || code === null) {
      ok("FIM application closed normally.");
    } else {
      err(`FIM application exited with code ${code}.`);
      console.log();
      console.log(`${C.yellow}Troubleshooting tips:${C.reset}`);
      console.log(`  1. Run setup:   ${C.cyan}node server.js --setup-only${C.reset}`);
      console.log(`  2. Run direct:  ${C.cyan}${python} main.py${C.reset}`);
      console.log(`  3. Check logs in fim_data.db or the Logs page`);
    }
    process.exit(code ?? 0);
  });

  child.on("error", (e) => {
    err(`Failed to start Python process: ${e.message}`);
    process.exit(1);
  });

  // ── Graceful shutdown on Ctrl+C ──────────────────────────────────────────
  process.on("SIGINT", () => {
    console.log();
    log("Shutting down FIM… (Ctrl+C received)");
    child.kill("SIGTERM");
    setTimeout(() => {
      child.kill("SIGKILL");
      process.exit(0);
    }, 3000);
  });

  process.on("SIGTERM", () => {
    child.kill("SIGTERM");
    process.exit(0);
  });
}

// ── Main ──────────────────────────────────────────────────────────────────────
function main() {
  printBanner();

  // Must be run from project root
  if (!fs.existsSync(MAIN_PY)) {
    err(`main.py not found at: ${MAIN_PY}`);
    err("Make sure server.js is placed in the FIM_SYSTEM root folder (same level as main.py).");
    process.exit(1);
  }

  const python = findPython();
  checkStructure();
  createDirs();
  installDeps(python);

  if (SETUP_ONLY) {
    console.log();
    ok("Setup complete. Run the app with:  node server.js");
    process.exit(0);
  }

  launchApp(python);
}

main();