"""
File Integrity Monitoring System (FIM)
Entry point - run this file to start the application.
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.app import FIMApp

if __name__ == "__main__":
    app = FIMApp()
    app.mainloop()
